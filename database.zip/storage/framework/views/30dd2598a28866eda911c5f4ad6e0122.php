<div>
    <!-- When there is no desire, all things are at peace. - Laozi -->
</div>
<?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/tour_package/show.blade.php ENDPATH**/ ?>