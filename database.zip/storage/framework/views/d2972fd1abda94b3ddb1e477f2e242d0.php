<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin.dashboard')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><?php echo e(auth()->user()->name); ?> <sup>2</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', 'admin.dashboard')): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', ['admin.social.media.show', 'admin.social.media.create', 'admin.social.media.storeOrUpdate'])): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.social.media.show')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Social Media</span></a>
    </li>

    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', ['admin.app.setting'])): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.app.setting')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Setting</span></a>
    </li>

    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', ['admin.show.profile', 'admin.edit.profile', 'admin.update.profile'])): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.show.profile')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Profile</span></a>
    </li>

    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', ['admin.contacts'])): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.contacts')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Contacts</span></a>
    </li>
    <li class="nav-item <?php if (\Illuminate\Support\Facades\Blade::check('active', ['admin.tour.package.list', 'admin.tour.package.create', 'admin.tour.package.edit'])): ?> active <?php endif; ?>">
        <a class="nav-link" href="<?php echo e(route('admin.tour.package.list')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Tour Packages</span></a>
    </li>


    


    <!-- Nav Item - Pages Collapse Menu -->
    

    <!-- Nav Item - Utilities Collapse Menu -->
    

    

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

    <!-- Sidebar Message -->
    

</ul>
<?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/layouts/leftsiderbar.blade.php ENDPATH**/ ?>