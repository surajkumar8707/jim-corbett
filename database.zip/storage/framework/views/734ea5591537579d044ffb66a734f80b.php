<script>
    // Set the options that I want
    toastr.options = {
    "closeButton": true,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-top-right",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "5000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
    }
</script>

<?php if(Session::has('success')): ?>
<script>
    toastr.success('<?php echo e(Session::get("success")); ?>','Success !');
</script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<script>
    toastr.error('<?php echo e(Session::get("error")); ?>','Error !');
</script>
<?php endif; ?>

<?php if(Session::has('info')): ?>
<script>
    toastr.info('<?php echo e(Session::get("info")); ?>','Information !');
</script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<script>
    toastr.warning('<?php echo e(Session::get("warning")); ?>','Warning !');
</script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/layouts/alert-message.blade.php ENDPATH**/ ?>