<?php $__env->startSection('content'); ?>
<div class="container-fluid">


    <div class="card shadow mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-sm-6">
                    <h4 class="card-title">Social Media Links</h4>
                </div>
                <div class="col-sm-6">
                    <?php if($socialMediaLinks): ?>
                        <a href="<?php echo e(route('admin.social.media.create')); ?>" class="btn btn-primary">Edit</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('admin.social.media.create')); ?>" class="btn btn-success">Add</a>
                    <?php endif; ?>
                </div>
            </div>

        </div>
        <div class="card-body">
            <div class="container">
                

                <ul class="list-group">
                    <?php if($socialMediaLinks): ?>
                        <li class="list-group-item"><strong class="ml-5">YouTube:</strong> <a href="<?php echo e($socialMediaLinks?->youTube); ?>"><?php echo e($socialMediaLinks?->youTube); ?></a></li>
                        <li class="list-group-item"><strong class="ml-5">Instagram:</strong> <a href="<?php echo e($socialMediaLinks?->instagram); ?>"><?php echo e($socialMediaLinks?->instagram); ?></a></li>
                        <li class="list-group-item"><strong class="ml-5">Facebook:</strong> <a href="<?php echo e($socialMediaLinks?->facebook); ?>"><?php echo e($socialMediaLinks?->facebook); ?></a></li>
                        <li class="list-group-item"><strong class="ml-5">LinkedIn:</strong> <a href="<?php echo e($socialMediaLinks?->linkedin); ?>"><?php echo e($socialMediaLinks?->linkedin); ?></a></li>
                    <?php else: ?>
                    <li class="list-group-item"><strong>YouTube:</strong> <?php echo e($socialMediaLinks?->youTube); ?></li>
                    <li class="list-group-item"><strong>Instagram:</strong> <?php echo e($socialMediaLinks?->instagram); ?></li>
                    <li class="list-group-item"><strong>Facebook:</strong> <?php echo e($socialMediaLinks?->facebook); ?></li>
                    <li class="list-group-item"><strong>LinkedIn:</strong> <?php echo e($socialMediaLinks?->linkedin); ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/social_media/show.blade.php ENDPATH**/ ?>