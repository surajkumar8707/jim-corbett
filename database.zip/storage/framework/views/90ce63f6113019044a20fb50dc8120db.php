<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Change Password</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <h1><?php echo e($user->name); ?>'s Profile</h1>



            <div class="row">
                <div class="col-md-6">
                    <!-- Display user information here -->
                    <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($user->phone); ?></p>
                    <p><strong>Address:</strong> <?php echo e($user->address); ?></p>
                    <p><strong>County:</strong> <?php echo e($user->county); ?></p>
                    <p><strong>State:</strong> <?php echo e($user->state); ?></p>
                    <p><strong>City:</strong> <?php echo e($user->city); ?></p>
                    <p><strong>Zipcode:</strong> <?php echo e($user->zipcode); ?></p>

                    <a href="<?php echo e(route('admin.edit.profile')); ?>" class="btn btn-primary">Edit Profile</a>
                </div>
                <div class="col-md-6">
                    <?php if($user->photo): ?>
                        <div class="mb-3">
                            <img src="<?php echo e(asset($user->photo)); ?>" alt="<?php echo e($user->name); ?>'s Photo">
                            
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/profile/show.blade.php ENDPATH**/ ?>