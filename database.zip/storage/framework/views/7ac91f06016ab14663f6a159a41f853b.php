<?php $__env->startSection('content'); ?>
    <!-- Header Start -->
    <div class="container-fluid page-header">
        <div class="container">
            <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 400px">
                <h3 class=" text-white text-uppercase"><?php echo e($package->name); ?></h3>
                <div class="d-inline-flex text-white">
                    <p class="m-0 text-uppercase"><a class="text-white" href="<?php echo e(route('home')); ?>">Home</a></p>
                    <i class="fa fa-angle-double-right pt-1 px-3"></i>
                    <p class="m-0 text-uppercase">Package Details</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->

    <!-- Package Details Content Start -->
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-6">
                <img class="img-fluid mb-4" src="<?php echo e(public_asset($package->images)); ?>" alt="Package Image">
            </div>
            <div class="col-lg-6">
                <h2><?php echo e($package->name); ?></h2>
                <p><?php echo e($package->description); ?></p>
                <p><strong>Price:</strong> $<?php echo e($package->price); ?></p>
                <p><strong>Duration:</strong> <?php echo e($package->duration); ?> days</p>
                <p><strong>Itinerary:</strong></p>
                <ul>
                    <?php $__currentLoopData = explode(PHP_EOL, $package->itinerary); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <!-- Add more details as needed -->
            </div>
        </div>
    </div>
    <!-- Package Details Content End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/package_details.blade.php ENDPATH**/ ?>