<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-md-6">
                    <h4 class="card-title">Tour Packages</h4>
                </div>
                <div class="col-md-6 text-right">
                    <a class="btn btn-primary" href="<?php echo e(route('admin.tour.package.create')); ?>">Add +</a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Duration</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tour_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($package->name); ?></td>
                                <td><?php echo e($package->price); ?></td>
                                <td><?php echo e($package->duration); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.tour.package.show', $package->id)); ?>"><i class="fas fa-fw fa-eye"></i></a>
                                    <a href="<?php echo e(route('admin.tour.package.edit', $package->id)); ?>"><i class="fas fa-fw fa-pencil-alt"></i></a>
                                    <a href="<?php echo e(route('admin.tour.package.delete', $package->id)); ?>"><i class="fas fa-fw fa-trash-alt"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <th class="text-center" colspan="10">No packages available in the table</th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admins.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tour-travels\resources\views/admins/tour_package/index.blade.php ENDPATH**/ ?>